from Live import load_game, welcome
welcome("Guy")
load_game()